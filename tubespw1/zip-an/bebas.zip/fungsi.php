<?php 

		//Koneksi database
	$koneksi = mysqli_connect("localhost", "root", "", "belajardoni");



	function query($query) {
		global $koneksi;
		$result = mysqli_query($koneksi, $query);
		$rows = [];
		while ( $row = mysqli_fetch_assoc($result) ) {
			$rows[] = $row;
		}
		return $rows;
	}



	function tambah($data) {
		global $koneksi;

		$nama = htmlspecialchars($data["nama"]);
		$email = htmlspecialchars($data["email"]);
		$nohp = htmlspecialchars($data["nohp"]);
		$hobi = htmlspecialchars($data["hobi"]);

	$query = "INSERT INTO daftar
				VALUES 
				('', '$nama', '$email', '$nohp', '$hobi')
			";
			mysqli_query($koneksi, $query);

			return mysqli_affected_rows($koneksi);
	}


	function hapus($id){
		global $koneksi;
		mysqli_query($koneksi, "DELETE FROM daftar WHERE id = $id");

		return mysqli_affected_rows($koneksi);
	}

	function ubah($data){
		global $koneksi;

		$id = $data["id"];
		$nama = htmlspecialchars($data["nama"]);
		$email = htmlspecialchars($data["email"]);
		$nohp = htmlspecialchars($data["nohp"]);
		$hobi = htmlspecialchars($data["hobi"]);

	$query = "UPDATE daftar SET 
				nama = '$nama', 
				email = '$email',
				nohp = '$nohp',
				hobi = '$hobi' 
				WHERE id = $id
			";
			mysqli_query($koneksi, $query);

			return mysqli_affected_rows($koneksi);
	}
 ?>