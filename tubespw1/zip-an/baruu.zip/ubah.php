<?php 

	require 'fungsi.php';

	// Ambil data dari url
	$id = $_GET["id"];
	var_dump($id);

	// query data mahasiswa berdasarkan id
	$maba = query("SELECT * FROM daftar WHERE id = $id")[0];

	// cek apakah tombol submit sudah ditekan atau belum
	if ( isset($_POST["submit"]) ) {
		
			// cek apakah data berhasil di tambahkan aatu tidak
			if (ubah($_POST) > 0) {
				echo "
					<script>
						alert('data berhasil diubah');
						document.location.href= 'index.php';
					</script>
				";
			}else{
				echo "
					<script>
						alert('data gaal diubah');
						document.location.href= 'index.php';
					</script>
				";
			}

}
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>ubah Data Teman Doni</title>
</head>
<body>
	
	<h1>ubah Data Teman Doni</h1>

	<form action="" method="post">
		<input type="hidden" name="id" value="<?= $maba["id"]; ?>">
		
		<ul>
			<li>
				<label for="nama">Nama : </label>
				<input type="text" name="nama" id="nama" required="required" value="<?= $maba["nama"]; ?>">
			</li>
			<li>
				<label for="email">Email : </label>
				<input type="text" name="email" id="email"required="required" value="<?= $maba["email"]; ?>">
			</li>
			<li>
				<label for="nohp">No Hp : </label>
				<input type="text" name="nohp" id="nohp"required="required" value="<?= $maba["nohp"]; ?>">
			</li>
			<li>
				<label for="hobi">Hobi : </label>
				<input type="text" name="hobi" id="hobi"required="required" value="<?= $maba["hobi"]; ?>">
			</li>

			<li>
				<button type="submit" name="submit">Ubah Daftar</button>
			</li>
			
		</ul>


	</form>
</body>
</html>