<?php 


		//Koneksi database
	$koneksi = mysqli_connect("localhost", "root", "", "belajardoni");



	function query($query) {
		global $koneksi;
		$result = mysqli_query($koneksi, $query);
		$rows = [];
		while ( $row = mysqli_fetch_assoc($result) ) {
			$rows[] = $row;
		}
		return $rows;
	}



	function tambah($data) {
		global $koneksi;

		$username = htmlspecialchars($data["username"]);
		$password = htmlspecialchars($data["password"]);
		$name = htmlspecialchars($data["name"]);
		$email = htmlspecialchars($data["email"]);

		//enkripsi password
		$password = password_hash($password, PASSWORD_DEFAULT);

	$query = "INSERT INTO akun2
				VALUES 
				('', '$username', '$password', '$name', '$email')
			";
			mysqli_query($koneksi, $query);

			return mysqli_affected_rows($koneksi);
	}


	function hapus($id){
		global $koneksi;
		mysqli_query($koneksi, "DELETE FROM akun2 WHERE id = $id");

		return mysqli_affected_rows($koneksi);
	}

	function ubah($data){
		global $koneksi;

		$id = $data["id"];
		$username = htmlspecialchars($data["username"]);
		$password = htmlspecialchars($data["password"]);
		$name = htmlspecialchars($data["name"]);
		$email = htmlspecialchars($data["email"]);

	$query = "UPDATE akun2 SET 
				username = '$username', 
				password = '$password',
				name = '$name',
				email = '$email' 
				WHERE id = $id
			";
			mysqli_query($koneksi, $query);

			return mysqli_affected_rows($koneksi);
	}

	function cari($keyword){
		$query = "SELECT * FROM akun2 
					WHERE
				username LIKE '%$keyword%' OR
				password LIKE '%$keyword%' OR
				name LIKE '%$keyword%' OR
				email LIKE '%$keyword%' 
					";
		return query($query);
	}


?>

	