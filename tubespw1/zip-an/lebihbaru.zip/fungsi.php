<?php 

		//Koneksi database
	$koneksi = mysqli_connect("localhost", "root", "", "belajardoni");



	function query($query) {
		global $koneksi;
		$result = mysqli_query($koneksi, $query);
		$rows = [];
		while ( $row = mysqli_fetch_assoc($result) ) {
			$rows[] = $row;
		}
		return $rows;
	}



	function tambah($data) {
		global $koneksi;

		$nama = htmlspecialchars($data["nama"]);
		$email = htmlspecialchars($data["email"]);
		$nohp = htmlspecialchars($data["nohp"]);
		$hobi = htmlspecialchars($data["hobi"]);

	$query = "INSERT INTO daftar
				VALUES 
				('', '$nama', '$email', '$nohp', '$hobi')
			";
			mysqli_query($koneksi, $query);

			return mysqli_affected_rows($koneksi);
	}


	function hapus($id){
		global $koneksi;
		mysqli_query($koneksi, "DELETE FROM daftar WHERE id = $id");

		return mysqli_affected_rows($koneksi);
	}

	function ubah($data){
		global $koneksi;

		$id = $data["id"];
		$nama = htmlspecialchars($data["nama"]);
		$email = htmlspecialchars($data["email"]);
		$nohp = htmlspecialchars($data["nohp"]);
		$hobi = htmlspecialchars($data["hobi"]);

	$query = "UPDATE daftar SET 
				nama = '$nama', 
				email = '$email',
				nohp = '$nohp',
				hobi = '$hobi' 
				WHERE id = $id
			";
			mysqli_query($koneksi, $query);

			return mysqli_affected_rows($koneksi);
	}

	function cari($keyword){
		$query = "SELECT * FROM daftar 
					WHERE
				nama LIKE '%$keyword%' OR
				email LIKE '%$keyword%' OR
				nohp LIKE '%$keyword%' OR
				hobi LIKE '%$keyword%' 
					";
		return query($query);
	}

	function registrasi($data){
		global $koneksi;

		$username = strtolower(stripslashes($data["username"]));
		$password = mysqli_real_escape_string($koneksi, $data["password"]);
		$password2 = mysqli_real_escape_string($koneksi, $data["password2"]);
		$email = ($data["email"]);

		// cek username udah ada atau belum
		$result = mysqli_query($koneksi, "SELECT username FROM akun
									WHERE username = '$username'");

		if (mysqli_fetch_assoc($result) ) {
			echo "<script>
					alert('username sudah terdaftar!!');
				 </script>
					";
			return false;
		}

		// cek konfirmasi password
		if ( $password !== $password2) {
			echo "<script>
						alert('Konfirmasi password tidak sesuai');
				  </script>
			";
			return false;
		}

		// enkripsi password
		$password = password_hash($password, PASSWORD_DEFAULT);

		// tamabhkan userbaru kedatabase
		mysqli_query($koneksi, "INSERT INTO akun VALUES ('', '$username', '$password', '$email')");

		return mysqli_affected_rows($koneksi);

	}













 ?>