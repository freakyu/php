<?php 

		//Koneksi database
	$koneksi = mysqli_connect("localhost", "root", "", "tubeskelompok1pw");



	function query($query) {
		global $koneksi;
		$result = mysqli_query($koneksi, $query);
		$rows = [];
		while ( $row = mysqli_fetch_assoc($result) ) {
			$rows[] = $row;
		}
		return $rows;
	}



	function tambah($data) {
		global $koneksi;

		$username = htmlspecialchars($data["username"]);
		$password = htmlspecialchars($data["password"]);
		$nama = htmlspecialchars($data["nama"]);
		$email = htmlspecialchars($data["email"]);

		//enkripsi password
		$password = password_hash($password, PASSWORD_DEFAULT);

	$query = "INSERT INTO data1
				VALUES 
				('', '$username', '$password', '$nama', '$email')
			";
			mysqli_query($koneksi, $query);

			return mysqli_affected_rows($koneksi);
	}


	function hapus($id){
		global $koneksi;
		mysqli_query($koneksi, "DELETE FROM data1 WHERE id = $id");

		return mysqli_affected_rows($koneksi);
	}

	function ubah($id){
		global $koneksi;
		mysqli_query($koneksi, "UPDATE data1 SET username,password,nama,email = $username,$password, $nama, $email WHERE id = $id");

		return mysqli_affected_rows($koneksi);
	}

 ?>