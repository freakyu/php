<?php 

$koneksi = mysqli_connect("localhost","root","","TubesKelompok1Pw");

// Check connection
if ($koneksi -> connect_error){
	die ("Koneksi database gagal".$koneksi -> connect_error);
}


?>